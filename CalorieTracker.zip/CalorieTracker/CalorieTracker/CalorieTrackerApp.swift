//
//  CalorieTrackerApp.swift
//  CalorieTracker
//
//  Created by padma karumuri on 5/3/23.
//

import SwiftUI

@main
struct CalorieTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
